"""
Explainable AI layer: SHAP for global feature attribution, LIME for
local/instance-level explanations of individual classification decisions.
"""

from __future__ import annotations
import numpy as np
import shap
from lime.lime_tabular import LimeTabularExplainer


def global_shap_explanation(model, X: np.ndarray, feature_names: list[str],
                             sample_size: int = 200, seed: int = 42):
    """Global feature attribution via SHAP TreeExplainer (works for RF/XGBoost).

    Returns (mean_abs_shap: dict[feature_name -> importance], shap_values)
    """
    rng = np.random.default_rng(seed)
    if len(X) > sample_size:
        idx = rng.choice(len(X), sample_size, replace=False)
        X_sample = X[idx]
    else:
        X_sample = X

    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_sample)

    # binary classifiers may return a list [class0, class1] or a single array
    if isinstance(shap_values, list):
        values = shap_values[1] if len(shap_values) > 1 else shap_values[0]
    else:
        values = shap_values
        if values.ndim == 3:  # (n, features, classes)
            values = values[:, :, -1]

    mean_abs = np.abs(values).mean(axis=0)
    importance = dict(sorted(
        zip(feature_names, mean_abs.tolist()),
        key=lambda kv: kv[1], reverse=True
    ))
    return importance, values


def local_lime_explanation(model, X_train: np.ndarray, instance: np.ndarray,
                            feature_names: list[str], class_names=("benign", "malicious"),
                            num_features: int = 6):
    """Local, instance-specific explanation for a single flow/packet decision."""
    explainer = LimeTabularExplainer(
        training_data=X_train,
        feature_names=feature_names,
        class_names=list(class_names),
        mode="classification",
        discretize_continuous=True,
    )

    predict_fn = model.predict_proba
    explanation = explainer.explain_instance(
        instance, predict_fn, num_features=num_features
    )
    return explanation.as_list()


if __name__ == "__main__":
    from data.synthetic_data import generate_dataset
    from features.feature_extraction import build_feature_matrix
    from models.random_forest_model import train_random_forest

    df = generate_dataset(2000)
    X, scaler, names = build_feature_matrix(df)
    y = df["is_malicious"].values

    clf, _ = train_random_forest(X, y, cv_folds=3)

    importance, _ = global_shap_explanation(clf, X, names)
    print("Top SHAP features (global):")
    for feat, val in list(importance.items())[:5]:
        print(f"  {feat}: {val:.4f}")

    explanation = local_lime_explanation(clf, X, X[0], names)
    print("\nLIME explanation for flow #0:")
    for feat, weight in explanation:
        print(f"  {feat}: {weight:.4f}")
