"""
Feature engineering aligned with the paper's Tables 2-6:
  - Table 2: packet header features (IP/TCP/UDP)
  - Table 3: flow metadata features
  - Table 4: payload features
  - Table 5: time-window features (1s / 1min / 1hr)
  - Table 6: statistical features

`build_feature_matrix` turns the raw synthetic (or real) flow records into:
  - a tabular feature matrix for Random Forest / XGBoost / Isolation Forest
  - a windowed sequence tensor for LSTM (temporal analysis)
  - a "byte pattern" tensor for CNN (payload analysis stand-in)
"""

from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

TABULAR_FEATURES = [
    "packet_size",
    "inter_arrival_time",
    "connection_rate",
    "payload_entropy",
    "ssl_tls_indicator",
    "uncommon_port",
    "syn_only_flag",
    "failed_login_count",
    "byte_rate",
    "packet_size_variance",
    "iat_coeff_variation",
]


def build_feature_matrix(df: pd.DataFrame, fit_scaler: StandardScaler | None = None):
    """Z-score normalize tabular features (per the paper's normalization step).

    Returns (X_scaled: np.ndarray, scaler: StandardScaler, feature_names: list[str])
    """
    X = df[TABULAR_FEATURES].values.astype(np.float32)
    if fit_scaler is None:
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
    else:
        scaler = fit_scaler
        X_scaled = scaler.transform(X)
    return X_scaled, scaler, TABULAR_FEATURES


def build_sliding_windows(df: pd.DataFrame, window: int = 20, stride: int = 10):
    """Sliding-window sequences over TABULAR_FEATURES for LSTM temporal
    analysis (paper: 100-packet window / 50-packet stride, scaled down here
    for a lightweight demo dataset).

    Returns (X_seq: [n_windows, window, n_features], y_seq: [n_windows])
    """
    X = df[TABULAR_FEATURES].values.astype(np.float32)
    y = df["is_malicious"].values.astype(np.float32)

    seqs, labels = [], []
    for start in range(0, len(df) - window, stride):
        end = start + window
        seqs.append(X[start:end])
        # window label = majority vote of malicious flag in the window
        labels.append(1.0 if y[start:end].mean() > 0.5 else 0.0)

    if not seqs:
        return np.empty((0, window, len(TABULAR_FEATURES))), np.empty((0,))

    return np.stack(seqs), np.array(labels)


def build_payload_bytes(df: pd.DataFrame, byte_len: int = 64, seed: int = 0):
    """Synthesize a pseudo byte-payload signal per flow, derived from
    entropy/packet-size features, for CNN-style payload pattern analysis.

    This stands in for real packet payload bytes (Table 4: N-gram / byte
    distribution features), which are not present in flow-level metadata.
    Returns X_bytes: [n_flows, byte_len, 1] scaled to [0, 1].
    """
    rng = np.random.default_rng(seed)
    n = len(df)
    entropy = df["payload_entropy"].values
    size = df["packet_size"].values

    bytes_matrix = np.zeros((n, byte_len), dtype=np.float32)
    for i in range(n):
        # higher entropy -> more uniform/random byte distribution
        scale = 1.0 + entropy[i] / 8.0
        base = rng.normal(loc=size[i] % 256, scale=40 * scale, size=byte_len)
        bytes_matrix[i] = np.clip(base, 0, 255)

    bytes_matrix = bytes_matrix / 255.0
    return bytes_matrix.reshape(n, byte_len, 1)


if __name__ == "__main__":
    from data.synthetic_data import generate_dataset

    df = generate_dataset(500)
    X, scaler, names = build_feature_matrix(df)
    X_seq, y_seq = build_sliding_windows(df)
    X_bytes = build_payload_bytes(df)
    print("tabular:", X.shape, "seq:", X_seq.shape, "bytes:", X_bytes.shape)
