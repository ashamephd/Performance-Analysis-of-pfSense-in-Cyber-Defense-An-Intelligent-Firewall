# AI-Enhanced pfSense-Style Intelligent Firewall (Reference Implementation)

Runnable Python implementation of the hierarchical AI firewall architecture
described in:

> V. Asha and S. Kanaga Suba Raja, **"Performance Analysis of pfSense in
> Cyber Defense: An Intelligent Firewall Perspective for the Modern Network
> Landscape,"** *IEEE Access*, vol. 14, pp. 90455–90486, 2026.
> DOI: [10.1109/ACCESS.2026.3699458](https://doi.org/10.1109/ACCESS.2026.3699458)

This repo is a **from-scratch reference implementation** of the paper's
proposed ML architecture — it is not the authors' original code (the paper
does not publish one). It reproduces the *design*: a hierarchical model
cascade (Random Forest → XGBoost → CNN/LSTM), an Isolation-Forest
behavioral baseline, and SHAP/LIME explainability — following the feature
schema in Tables 2–6 and the model hyperparameters in Table 7 /
Section IV‑I of the paper.

## Why synthetic data?

The paper trains on CICIDS2017, NSL-KDD, TON_IoT, BoT-IoT, and
CIC-DDoS2019 — large, separately-licensed public datasets that can't be
redistributed inside a code repo. `data/synthetic_data.py` generates
statistically similar labeled traffic (benign / DDoS / port scan /
brute force / malware / a held-out "zero-day" class) so the whole
pipeline runs out of the box. **To use real data:** point
`features/feature_extraction.py` at your downloaded CICIDS2017/NSL-KDD
CSVs and map their columns onto `TABULAR_FEATURES`.

## Architecture

```
Incoming flow
     │
     ▼
[Random Forest]  <-- fast packet/flow triage (all traffic)
     │  confident?  ──yes──► final decision
     │  ambiguous (prob in [0.35, 0.65])
     ▼
[XGBoost]  <-- flow-level statistical features, higher accuracy
     │  still ambiguous (prob in [0.4, 0.6])
     ▼
[CNN]  <-- byte/payload pattern deep inspection
     │
     ▼
final decision

(in parallel, independent of the chain above)
[Isolation Forest] <-- unsupervised behavioral baseline / zero-day safety net

Every model decision can be explained via:
[SHAP]  <-- global feature attribution
[LIME]  <-- local, per-flow explanation
```

Only traffic that's genuinely ambiguous gets escalated to the more
expensive models — this is the "AI optimization" the paper describes
(Section IV‑B): avoid needless deep processing of easy traffic.

## Project layout

```
pfsense-ai-firewall/
├── data/
│   └── synthetic_data.py          # traffic generator (Tables 2-6 schema)
├── features/
│   └── feature_extraction.py      # tabular / sliding-window / byte features
├── models/
│   ├── random_forest_model.py     # Table 7: 200 trees, depth 15
│   ├── xgboost_model.py           # Table 7: lr=0.1, 200 estimators, depth 7
│   ├── cnn_model.py                # Section VI: 32/64-filter Conv1D
│   ├── lstm_model.py               # Section VI: temporal flow sequences
│   └── isolation_forest_model.py  # Section IV-I: 150 estimators, contamination 0.05
├── explainability/
│   └── shap_lime_explain.py       # Section VIII-B.3/B.4
├── pipeline/
│   └── hierarchical_firewall.py   # Figure 2 / Section IV-B triage cascade
├── evaluate/
│   └── metrics.py                 # Table 8-style baseline vs AI comparison
├── tests/
│   └── test_pipeline.py
├── main.py                         # end-to-end demo
└── requirements.txt
```

## Quickstart

```bash
git clone <this-repo>
cd pfsense-ai-firewall
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt

python3 main.py --train-size 8000 --test-size 2000
```

Run the test suite:

```bash
python3 -m pytest tests/ -q
```

Run an individual component:

```bash
python3 -m models.random_forest_model
python3 -m models.xgboost_model
python3 -m models.cnn_model
python3 -m models.lstm_model
python3 -m models.isolation_forest_model
python3 -m explainability.shap_lime_explain
python3 -m evaluate.metrics
```

## What this does and doesn't reproduce

**Does reproduce:**
- The hierarchical triage design (lightweight models first, deep models only on ambiguous traffic)
- The feature families in Tables 2–6 (packet header, flow metadata, payload, time-window, statistical)
- The model hyperparameters listed in Table 7 / Section IV‑I
- SHAP (global) + LIME (local) explainability on the classifier decisions
- A baseline-vs-AI-optimized comparison in the spirit of Table 8

**Does not reproduce:**
- The paper's exact reported percentages (14.1% throughput gain, 97.3%
  RF accuracy, etc.) — those come from real hardware testbeds
  (Xeon E5-2670 v3, 32 GB RAM, physical pfSense 2.6.0/FreeBSD 12.3
  deployments) and real public datasets, neither of which is available here.
- Actual pfSense/FreeBSD kernel-module integration — this is a standalone
  ML pipeline, not a pfSense package.
- Real packet payload bytes — `build_payload_bytes()` synthesizes a
  byte-like signal from entropy/size features as a stand-in for actual
  n-gram/payload analysis (Table 4).

## Extending toward the real deployment described in the paper

1. Replace `data/synthetic_data.py` with loaders for CICIDS2017 / NSL-KDD / TON_IoT / BoT-IoT / CIC-DDoS2019.
2. Feed real packet payload bytes into `build_payload_bytes()` (or bypass it and feed raw payload directly into the CNN).
3. Package the trained models behind a FreeBSD kernel module or a userspace daemon that mirrors pfSense's packet filter (`pf`) hooks, as described in Section VI.
4. Wire SHAP/LIME output into a pfSense GUI panel for administrator-facing explanations (Section VIII‑A).

## License

MIT — see `LICENSE`. This is an independent, unaffiliated reference
implementation for research/educational purposes; it is not published or
endorsed by the paper's authors or IEEE Access.
