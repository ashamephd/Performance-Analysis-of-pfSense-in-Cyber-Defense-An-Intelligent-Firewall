"""
End-to-end demo of the AI-enhanced pfSense-style hierarchical firewall
described in:

    V. Asha and S. Kanaga Suba Raja, "Performance Analysis of pfSense in
    Cyber Defense: An Intelligent Firewall Perspective for the Modern
    Network Landscape," IEEE Access, vol. 14, 2026.

Runs: synthetic data generation -> feature engineering -> hierarchical
RF/XGBoost/CNN triage -> Isolation Forest behavioral safety net ->
SHAP/LIME explainability -> baseline-vs-AI-optimized comparison.

Usage:
    python3 main.py --train-size 8000 --test-size 2000
"""

from __future__ import annotations
import argparse
import json

from data.synthetic_data import generate_dataset
from pipeline.hierarchical_firewall import HierarchicalFirewall
from evaluate.metrics import compare_baseline_vs_ai
from explainability.shap_lime_explain import global_shap_explanation, local_lime_explanation
from features.feature_extraction import build_feature_matrix


def main():
    parser = argparse.ArgumentParser(description="AI-enhanced pfSense-style firewall demo")
    parser.add_argument("--train-size", type=int, default=8000)
    parser.add_argument("--test-size", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    print("=" * 70)
    print("1. Generating synthetic traffic (stand-in for CICIDS2017/NSL-KDD)")
    print("=" * 70)
    train_df = generate_dataset(args.train_size, seed=args.seed)
    test_df = generate_dataset(args.test_size, seed=args.seed + 1)
    print(train_df["label"].value_counts(), "\n")

    print("=" * 70)
    print("2. Training hierarchical AI firewall stack")
    print("   (Random Forest -> XGBoost -> CNN, + Isolation Forest baseline)")
    print("=" * 70)
    fw = HierarchicalFirewall()
    train_metrics = fw.fit(train_df)
    print(json.dumps(train_metrics, indent=2, default=float), "\n")

    print("=" * 70)
    print("3. Running tiered inference on held-out test traffic")
    print("=" * 70)
    results = fw.predict(test_df)
    print("Decision tier distribution:")
    print(results["decision_tier"].value_counts())
    print(f"Mean end-to-end latency: {results['pipeline_latency_ms'].mean():.3f} ms/flow\n")

    print("=" * 70)
    print("4. Baseline (RF-only) vs AI-optimized pipeline comparison")
    print("=" * 70)
    comparison = compare_baseline_vs_ai(fw, test_df)
    print(comparison.to_string(index=False), "\n")

    print("=" * 70)
    print("5. Explainability: SHAP (global) + LIME (per-instance)")
    print("=" * 70)
    X, _, names = build_feature_matrix(test_df, fit_scaler=fw.scaler)
    importance, _ = global_shap_explanation(fw.rf_model, X, names)
    print("Top global SHAP feature attributions (Random Forest):")
    for feat, val in list(importance.items())[:5]:
        print(f"  {feat:24s} {val:.4f}")

    flagged = results[results["final_prediction"] == 1]
    if len(flagged) > 0:
        sample_idx = flagged.index[0]
        sample_pos = test_df.index.get_loc(sample_idx)
        explanation = local_lime_explanation(fw.rf_model, X, X[sample_pos], names)
        print(f"\nLIME explanation for flagged flow #{sample_idx} "
              f"(true label={test_df.loc[sample_idx, 'label']}):")
        for feat, weight in explanation:
            print(f"  {feat:30s} {weight:+.4f}")

    print("\nDone.")


if __name__ == "__main__":
    main()
