"""
Hierarchical AI-optimized firewall pipeline (mirrors Figure 2 / Section IV-B):

  1. Random Forest triages ALL traffic at packet/flow level (fast, cheap).
  2. Only traffic RF flags as suspicious (or borderline) is escalated to
     XGBoost for higher-accuracy flow-level classification.
  3. Traffic still ambiguous after XGBoost is escalated further to the
     CNN (payload pattern) and LSTM (temporal pattern) models.
  4. An Isolation Forest baseline runs in parallel as a behavioral/zero-day
     safety net, independent of the supervised triage chain.
  5. Every escalation decision is explainable via SHAP (global) and
     LIME (per-instance).

This "only suspicious traffic goes deeper" design is what the paper calls
the AI optimization that avoids needless deep processing.
"""

from __future__ import annotations
import time
import numpy as np
import pandas as pd

from features.feature_extraction import build_feature_matrix, build_payload_bytes
from models.random_forest_model import train_random_forest
from models.xgboost_model import train_xgboost
from models.cnn_model import train_cnn
from models.isolation_forest_model import train_isolation_forest, score_anomalies


class HierarchicalFirewall:
    """Trains the tiered model stack and runs traffic through it."""

    def __init__(self, rf_threshold: float = 0.5, xgb_threshold: float = 0.5,
                 escalate_band: tuple[float, float] = (0.35, 0.65)):
        self.rf_threshold = rf_threshold
        self.xgb_threshold = xgb_threshold
        self.escalate_band = escalate_band  # RF prob range that triggers XGBoost

        self.scaler = None
        self.feature_names = None
        self.rf_model = None
        self.xgb_model = None
        self.cnn_model = None
        self.iso_model = None

    def fit(self, df: pd.DataFrame):
        X, scaler, names = build_feature_matrix(df)
        y = df["is_malicious"].values
        self.scaler, self.feature_names = scaler, names

        self.rf_model, rf_cv = train_random_forest(X, y, cv_folds=5)
        self.xgb_model, xgb_metrics, _ = train_xgboost(X, y)

        X_bytes = build_payload_bytes(df)
        self.cnn_model, cnn_metrics, _ = train_cnn(X_bytes, y.astype(np.float32), epochs=5)

        benign_mask = y == 0
        self.iso_model = train_isolation_forest(X[benign_mask])

        return {
            "rf_cv_accuracy_mean": float(rf_cv.mean()),
            "xgb_metrics": xgb_metrics,
            "cnn_metrics": cnn_metrics,
        }

    def predict(self, df: pd.DataFrame) -> pd.DataFrame:
        """Runs the full tiered pipeline and returns per-flow decisions,
        the tier that made the final call, and per-tier latency (ms)."""
        X, _, _ = build_feature_matrix(df, fit_scaler=self.scaler)
        X_bytes = build_payload_bytes(df)

        results = []
        t0 = time.perf_counter()
        rf_proba = self.rf_model.predict_proba(X)[:, 1]
        rf_latency_ms = (time.perf_counter() - t0) * 1000 / max(1, len(df))

        lo, hi = self.escalate_band
        needs_escalation = (rf_proba >= lo) & (rf_proba <= hi)

        final_pred = (rf_proba >= self.rf_threshold).astype(int)
        decision_tier = np.array(["random_forest"] * len(df), dtype=object)
        total_latency_ms = np.full(len(df), rf_latency_ms)

        if needs_escalation.any():
            idx = np.where(needs_escalation)[0]
            t1 = time.perf_counter()
            xgb_proba = self.xgb_model.predict_proba(X[idx])[:, 1]
            xgb_latency = (time.perf_counter() - t1) * 1000 / len(idx)

            final_pred[idx] = (xgb_proba >= self.xgb_threshold).astype(int)
            decision_tier[idx] = "xgboost"
            total_latency_ms[idx] += xgb_latency

            still_ambiguous = idx[(xgb_proba >= 0.4) & (xgb_proba <= 0.6)]
            if len(still_ambiguous) > 0:
                t2 = time.perf_counter()
                cnn_proba = self.cnn_model.predict(X_bytes[still_ambiguous], verbose=0).ravel()
                cnn_latency = (time.perf_counter() - t2) * 1000 / len(still_ambiguous)

                final_pred[still_ambiguous] = (cnn_proba >= 0.5).astype(int)
                decision_tier[still_ambiguous] = "cnn_deep_inspection"
                total_latency_ms[still_ambiguous] += cnn_latency

        # Isolation Forest runs as an independent behavioral safety net
        is_anomaly, iso_scores = score_anomalies(self.iso_model, X)

        out = df.copy()
        out["rf_probability"] = rf_proba
        out["final_prediction"] = final_pred
        out["decision_tier"] = decision_tier
        out["pipeline_latency_ms"] = total_latency_ms
        out["isolation_forest_anomaly"] = is_anomaly
        out["isolation_forest_score"] = iso_scores
        return out


if __name__ == "__main__":
    from data.synthetic_data import generate_dataset

    train_df = generate_dataset(6000, seed=1)
    test_df = generate_dataset(1500, seed=2)

    fw = HierarchicalFirewall()
    train_metrics = fw.fit(train_df)
    print("Training metrics:", train_metrics)

    results = fw.predict(test_df)
    print("\nDecision tier distribution:")
    print(results["decision_tier"].value_counts())
    print(f"\nMean end-to-end latency: {results['pipeline_latency_ms'].mean():.3f} ms/flow")

    acc = (results["final_prediction"] == results["is_malicious"]).mean()
    print(f"Overall pipeline accuracy: {acc:.4f}")
