"""
CNN: deep-packet-inspection model over byte-level payload signals.

Paper spec (Section VI): two conv layers (32 and 64 filters), n-gram-style
local pattern capture, pooling for shift-invariance; reported ~96.8%
accuracy / 3-5 ms latency for APT/polymorphic-malware identification.
"""

from __future__ import annotations
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models


def build_cnn(input_len: int = 64) -> tf.keras.Model:
    model = models.Sequential([
        layers.Input(shape=(input_len, 1)),
        layers.Conv1D(32, kernel_size=3, activation="relu", padding="same"),
        layers.MaxPooling1D(2),
        layers.Conv1D(64, kernel_size=3, activation="relu", padding="same"),
        layers.GlobalMaxPooling1D(),
        layers.Dense(32, activation="relu"),
        layers.Dropout(0.3),
        layers.Dense(1, activation="sigmoid"),
    ])
    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
    return model


def train_cnn(X_bytes: np.ndarray, y: np.ndarray, epochs: int = 5, batch_size: int = 64,
              seed: int = 42):
    tf.random.set_seed(seed)
    n = len(X_bytes)
    idx = np.random.default_rng(seed).permutation(n)
    split = int(n * 0.8)
    train_idx, test_idx = idx[:split], idx[split:]

    model = build_cnn(input_len=X_bytes.shape[1])
    history = model.fit(
        X_bytes[train_idx], y[train_idx],
        validation_data=(X_bytes[test_idx], y[test_idx]),
        epochs=epochs, batch_size=batch_size, verbose=0,
    )
    loss, acc = model.evaluate(X_bytes[test_idx], y[test_idx], verbose=0)
    return model, {"test_loss": loss, "test_accuracy": acc}, history


if __name__ == "__main__":
    from data.synthetic_data import generate_dataset
    from features.feature_extraction import build_payload_bytes

    df = generate_dataset(3000)
    X_bytes = build_payload_bytes(df)
    y = df["is_malicious"].values.astype(np.float32)

    model, metrics, _ = train_cnn(X_bytes, y, epochs=3)
    print("CNN test metrics:", metrics)
