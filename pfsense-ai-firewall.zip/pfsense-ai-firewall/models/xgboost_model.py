"""
XGBoost: flow-level classifier using statistical/flow features for higher
detection accuracy (Table 7: lr=0.1, n_estimators=200, max_depth=7,
98.2% detection accuracy, 1-2 ms/flow inference).
"""

from __future__ import annotations
import numpy as np
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support


def train_xgboost(X: np.ndarray, y: np.ndarray, learning_rate: float = 0.1,
                   n_estimators: int = 200, max_depth: int = 7, seed: int = 42):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=seed, stratify=y
    )
    clf = XGBClassifier(
        learning_rate=learning_rate,
        n_estimators=n_estimators,
        max_depth=max_depth,
        eval_metric="logloss",
        random_state=seed,
        n_jobs=-1,
    )
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    prec, rec, f1, _ = precision_recall_fscore_support(y_test, y_pred, average="binary")

    metrics = {"accuracy": acc, "precision": prec, "recall": rec, "f1": f1}
    return clf, metrics, (X_test, y_test)


if __name__ == "__main__":
    from data.synthetic_data import generate_dataset
    from features.feature_extraction import build_feature_matrix

    df = generate_dataset(4000)
    X, scaler, names = build_feature_matrix(df)
    y = df["is_malicious"].values

    clf, metrics, _ = train_xgboost(X, y)
    print("XGBoost test metrics:", metrics)
