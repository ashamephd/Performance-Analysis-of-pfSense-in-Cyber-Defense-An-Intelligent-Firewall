"""
Isolation Forest: unsupervised behavioral-baseline anomaly detector.

Paper spec (Section IV-I): 150 estimators, contamination rate 0.05,
72-hour "period of normalcy" to build a behavior baseline. Here the
"normalcy period" is approximated by fitting only on benign-labeled flows.
"""

from __future__ import annotations
import numpy as np
from sklearn.ensemble import IsolationForest


def train_isolation_forest(X_benign: np.ndarray, n_estimators: int = 150,
                            contamination: float = 0.05, seed: int = 42):
    model = IsolationForest(
        n_estimators=n_estimators,
        contamination=contamination,
        random_state=seed,
        n_jobs=-1,
    )
    model.fit(X_benign)
    return model


def score_anomalies(model: IsolationForest, X: np.ndarray):
    """Returns (is_anomaly: bool array, anomaly_score: float array).
    Lower score = more anomalous (sklearn convention)."""
    preds = model.predict(X)  # -1 = anomaly, 1 = normal
    scores = model.decision_function(X)
    is_anomaly = preds == -1
    return is_anomaly, scores


if __name__ == "__main__":
    from data.synthetic_data import generate_dataset
    from features.feature_extraction import build_feature_matrix

    df = generate_dataset(4000)
    X, scaler, names = build_feature_matrix(df)
    benign_mask = df["is_malicious"].values == 0

    model = train_isolation_forest(X[benign_mask])
    is_anomaly, scores = score_anomalies(model, X)

    detected_rate = is_anomaly[~benign_mask].mean()
    false_alarm_rate = is_anomaly[benign_mask].mean()
    print(f"Anomaly detection rate on malicious flows: {detected_rate:.3f}")
    print(f"False alarm rate on benign flows: {false_alarm_rate:.3f}")
