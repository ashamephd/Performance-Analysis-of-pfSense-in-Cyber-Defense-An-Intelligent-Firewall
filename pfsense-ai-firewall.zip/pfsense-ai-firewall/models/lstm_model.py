"""
LSTM: temporal analysis of sliding-window flow sequences.

Paper spec (Section VI): identifies multi-stage/coordinated attacks via
sequence numbers, ack, flow durations, state transitions; reported ~92.3%
accuracy, 5-8 ms/flow.
"""

from __future__ import annotations
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models


def build_lstm(window: int, n_features: int) -> tf.keras.Model:
    model = models.Sequential([
        layers.Input(shape=(window, n_features)),
        layers.LSTM(64, return_sequences=True),
        layers.LSTM(32),
        layers.Dense(16, activation="relu"),
        layers.Dropout(0.3),
        layers.Dense(1, activation="sigmoid"),
    ])
    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
    return model


def train_lstm(X_seq: np.ndarray, y_seq: np.ndarray, epochs: int = 8, batch_size: int = 32,
               seed: int = 42):
    tf.random.set_seed(seed)
    n = len(X_seq)
    idx = np.random.default_rng(seed).permutation(n)
    split = int(n * 0.8)
    train_idx, test_idx = idx[:split], idx[split:]

    model = build_lstm(window=X_seq.shape[1], n_features=X_seq.shape[2])
    history = model.fit(
        X_seq[train_idx], y_seq[train_idx],
        validation_data=(X_seq[test_idx], y_seq[test_idx]),
        epochs=epochs, batch_size=batch_size, verbose=0,
    )
    loss, acc = model.evaluate(X_seq[test_idx], y_seq[test_idx], verbose=0)
    return model, {"test_loss": loss, "test_accuracy": acc}, history


if __name__ == "__main__":
    from data.synthetic_data import generate_dataset
    from features.feature_extraction import build_sliding_windows

    df = generate_dataset(4000)
    X_seq, y_seq = build_sliding_windows(df, window=20, stride=10)
    model, metrics, _ = train_lstm(X_seq, y_seq, epochs=5)
    print("LSTM test metrics:", metrics)
