"""
Random Forest: lightweight packet/flow-level triage classifier.

Paper spec (Section IV-I): max 200 decision trees, max depth 15, trained on
CICIDS2017 + NSL-KDD, achieving 97.3% accuracy via 10-fold CV. Here it is
trained on the synthetic dataset with the same hyperparameters.
"""

from __future__ import annotations
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score


def train_random_forest(X: np.ndarray, y: np.ndarray, n_estimators: int = 200,
                         max_depth: int = 15, cv_folds: int = 10, seed: int = 42):
    clf = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        n_jobs=-1,
        random_state=seed,
        class_weight="balanced",
    )
    cv_scores = cross_val_score(clf, X, y, cv=cv_folds, scoring="accuracy", n_jobs=-1)
    clf.fit(X, y)
    return clf, cv_scores


if __name__ == "__main__":
    from data.synthetic_data import generate_dataset
    from features.feature_extraction import build_feature_matrix

    df = generate_dataset(4000)
    X, scaler, names = build_feature_matrix(df)
    y = df["is_malicious"].values

    clf, cv_scores = train_random_forest(X, y, cv_folds=5)
    print(f"RF 5-fold CV accuracy: mean={cv_scores.mean():.4f} std={cv_scores.std():.4f}")
