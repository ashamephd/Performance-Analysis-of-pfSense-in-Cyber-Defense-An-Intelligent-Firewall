"""
Synthetic network-traffic data generator.

The paper trains on public datasets (CICIDS2017, NSL-KDD, TON_IoT, BoT-IoT,
CIC-DDoS2019) that are large, license-restricted, and not redistributable in
a code repo. This module generates *statistically similar* synthetic traffic
so the rest of the pipeline (feature engineering -> RF/XGBoost triage ->
CNN/LSTM deep inspection -> Isolation Forest anomaly detection -> SHAP/LIME
explainability) is fully runnable end-to-end without external downloads.

To use real data instead: replace `generate_dataset()` with a loader that
reads CICIDS2017/NSL-KDD CSVs and maps their columns onto the same
feature schema defined in features/feature_extraction.py.
"""

from __future__ import annotations
import numpy as np
import pandas as pd

RNG_SEED = 42

ATTACK_TYPES = [
    "benign",
    "ddos",
    "port_scan",
    "brute_force",
    "malware",
    "zero_day",  # held-out novel pattern, used only for generalization tests
]


def _packet_size_stats(rng, n, mean, std, lo, hi):
    sizes = rng.normal(mean, std, n)
    sizes = np.clip(sizes, lo, hi)
    return sizes


def _make_class(rng: np.random.Generator, n: int, label: str) -> pd.DataFrame:
    """Generate n rows of synthetic packet/flow/payload/statistical features
    for a given traffic class, following Tables 2-6 in the paper."""

    if label == "benign":
        pkt_size = _make_series(rng, n, 500, 300, 40, 1500)
        iat = rng.exponential(0.02, n)
        conn_rate = rng.normal(5, 2, n).clip(0, None)
        entropy = rng.normal(4.5, 0.8, n).clip(0, 8)
        ssl_flag = rng.binomial(1, 0.6, n)
        port_uncommon = rng.binomial(1, 0.03, n)
        syn_only = rng.binomial(1, 0.02, n)
        failed_login = rng.poisson(0.05, n)

    elif label == "ddos":
        pkt_size = _make_series(rng, n, 80, 20, 40, 200)
        iat = rng.exponential(0.0005, n)
        conn_rate = rng.normal(800, 200, n).clip(50, None)
        entropy = rng.normal(2.0, 0.5, n).clip(0, 8)
        ssl_flag = rng.binomial(1, 0.05, n)
        port_uncommon = rng.binomial(1, 0.2, n)
        syn_only = rng.binomial(1, 0.85, n)
        failed_login = rng.poisson(0.0, n)

    elif label == "port_scan":
        pkt_size = _make_series(rng, n, 60, 10, 40, 100)
        iat = rng.exponential(0.001, n)
        conn_rate = rng.normal(300, 100, n).clip(20, None)
        entropy = rng.normal(1.5, 0.3, n).clip(0, 8)
        ssl_flag = rng.binomial(1, 0.01, n)
        port_uncommon = rng.binomial(1, 0.9, n)
        syn_only = rng.binomial(1, 0.95, n)
        failed_login = rng.poisson(0.0, n)

    elif label == "brute_force":
        pkt_size = _make_series(rng, n, 150, 40, 60, 400)
        iat = rng.exponential(0.05, n)
        conn_rate = rng.normal(20, 5, n).clip(1, None)
        entropy = rng.normal(3.0, 0.5, n).clip(0, 8)
        ssl_flag = rng.binomial(1, 0.4, n)
        port_uncommon = rng.binomial(1, 0.1, n)
        syn_only = rng.binomial(1, 0.05, n)
        failed_login = rng.poisson(8.0, n)

    elif label == "malware":
        pkt_size = _make_series(rng, n, 900, 350, 100, 1500)
        iat = rng.exponential(0.01, n)
        conn_rate = rng.normal(15, 6, n).clip(1, None)
        entropy = rng.normal(7.2, 0.4, n).clip(0, 8)  # high entropy: encrypted/packed payload
        ssl_flag = rng.binomial(1, 0.8, n)
        port_uncommon = rng.binomial(1, 0.35, n)
        syn_only = rng.binomial(1, 0.05, n)
        failed_login = rng.poisson(0.1, n)

    elif label == "zero_day":
        # Deliberately blends benign + malware traits with added jitter,
        # simulating a previously-unseen polymorphic attack pattern.
        pkt_size = _make_series(rng, n, 700, 400, 40, 1500)
        iat = rng.exponential(0.015, n)
        conn_rate = rng.normal(45, 25, n).clip(0, None)
        entropy = rng.normal(6.0, 1.2, n).clip(0, 8)
        ssl_flag = rng.binomial(1, 0.7, n)
        port_uncommon = rng.binomial(1, 0.25, n)
        syn_only = rng.binomial(1, 0.15, n)
        failed_login = rng.poisson(1.5, n)

    else:
        raise ValueError(f"unknown label {label}")

    df = pd.DataFrame({
        "packet_size": pkt_size,
        "inter_arrival_time": iat,
        "connection_rate": conn_rate,
        "payload_entropy": entropy,
        "ssl_tls_indicator": ssl_flag,
        "uncommon_port": port_uncommon,
        "syn_only_flag": syn_only,
        "failed_login_count": failed_login,
    })

    # derived / flow-level features (Table 3, Table 6)
    df["byte_rate"] = df["packet_size"] * df["connection_rate"]
    df["packet_size_variance"] = df["packet_size"].rolling(5, min_periods=1).var().fillna(0)
    df["iat_coeff_variation"] = (
        df["inter_arrival_time"].rolling(5, min_periods=1).std().fillna(0)
        / df["inter_arrival_time"].rolling(5, min_periods=1).mean().replace(0, 1e-6)
    )
    df["label"] = label
    df["is_malicious"] = 0 if label == "benign" else 1
    return df


def _make_series(rng, n, mean, std, lo, hi):
    x = rng.normal(mean, std, n)
    return np.clip(x, lo, hi)


def generate_dataset(
    n_total: int = 20000,
    class_ratios: dict | None = None,
    seed: int = RNG_SEED,
) -> pd.DataFrame:
    """Generate a labeled synthetic dataset spanning benign + attack classes.

    Parameters
    ----------
    n_total : total number of flow records to generate
    class_ratios : optional dict {label: proportion}; defaults to a
        realistic imbalanced mix dominated by benign traffic.
    """
    rng = np.random.default_rng(seed)

    if class_ratios is None:
        class_ratios = {
            "benign": 0.70,
            "ddos": 0.08,
            "port_scan": 0.07,
            "brute_force": 0.06,
            "malware": 0.06,
            "zero_day": 0.03,
        }

    frames = []
    for label, ratio in class_ratios.items():
        n = max(1, int(n_total * ratio))
        frames.append(_make_class(rng, n, label))

    df = pd.concat(frames, ignore_index=True)
    df = df.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    df["flow_id"] = np.arange(len(df))
    return df


if __name__ == "__main__":
    data = generate_dataset(2000)
    print(data.groupby("label").size())
    print(data.head())
