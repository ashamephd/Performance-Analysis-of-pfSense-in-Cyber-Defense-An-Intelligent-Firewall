"""
Reproduces the paper's baseline-vs-AI-optimized comparison methodology
(Table 8 / Section VIII-E): a "baseline" (rule-based / RF-only, no
escalation, no XAI) is compared against the full hierarchical AI pipeline
on the same held-out test set, across accuracy, false positive rate,
false negative rate, and latency.

This is a fair, from-scratch statistical comparison against synthetic data
-- it does not reproduce the paper's exact reported numbers, which came
from real hardware testbeds and public datasets the paper does not
distribute in reusable form.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix


def _rates(y_true, y_pred):
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    accuracy = (tp + tn) / (tp + tn + fp + fn)
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    fnr = fn / (fn + tp) if (fn + tp) > 0 else 0.0
    return {"accuracy": accuracy, "false_positive_rate": fpr, "false_negative_rate": fnr}


def compare_baseline_vs_ai(fw, test_df: pd.DataFrame) -> pd.DataFrame:
    """`fw` is a fitted HierarchicalFirewall. Baseline = Random Forest tier
    only, thresholded at 0.5, no escalation. AI-optimized = full pipeline
    output already computed via fw.predict()."""
    from features.feature_extraction import build_feature_matrix

    X, _, _ = build_feature_matrix(test_df, fit_scaler=fw.scaler)
    y_true = test_df["is_malicious"].values

    rf_only_pred = (fw.rf_model.predict_proba(X)[:, 1] >= 0.5).astype(int)
    baseline_rates = _rates(y_true, rf_only_pred)

    full_results = fw.predict(test_df)
    ai_rates = _rates(y_true, full_results["final_prediction"].values)

    rows = [
        {"configuration": "baseline (RF only, no escalation)", **baseline_rates,
         "mean_latency_ms": float(full_results["pipeline_latency_ms"].min())},
        {"configuration": "AI-optimized (hierarchical pipeline)", **ai_rates,
         "mean_latency_ms": float(full_results["pipeline_latency_ms"].mean())},
    ]
    return pd.DataFrame(rows)


if __name__ == "__main__":
    from data.synthetic_data import generate_dataset
    from pipeline.hierarchical_firewall import HierarchicalFirewall

    train_df = generate_dataset(6000, seed=1)
    test_df = generate_dataset(1500, seed=2)

    fw = HierarchicalFirewall()
    fw.fit(train_df)

    comparison = compare_baseline_vs_ai(fw, test_df)
    print(comparison.to_string(index=False))
