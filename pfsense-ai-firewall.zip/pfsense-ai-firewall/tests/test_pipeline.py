"""Minimal smoke tests. Run with: python3 -m pytest tests/ -q"""
import numpy as np

from data.synthetic_data import generate_dataset
from features.feature_extraction import build_feature_matrix, build_sliding_windows, build_payload_bytes
from models.random_forest_model import train_random_forest
from models.isolation_forest_model import train_isolation_forest, score_anomalies
from pipeline.hierarchical_firewall import HierarchicalFirewall


def test_data_generation():
    df = generate_dataset(500)
    assert len(df) > 0
    assert set(df["label"].unique()) <= {
        "benign", "ddos", "port_scan", "brute_force", "malware", "zero_day"
    }


def test_feature_matrix_shapes():
    df = generate_dataset(300)
    X, scaler, names = build_feature_matrix(df)
    assert X.shape[0] == len(df)
    assert X.shape[1] == len(names)


def test_sliding_windows():
    df = generate_dataset(300)
    X_seq, y_seq = build_sliding_windows(df, window=10, stride=5)
    assert X_seq.shape[0] == y_seq.shape[0]
    assert X_seq.shape[1] == 10


def test_random_forest_trains():
    df = generate_dataset(500)
    X, _, _ = build_feature_matrix(df)
    y = df["is_malicious"].values
    clf, cv_scores = train_random_forest(X, y, cv_folds=3)
    assert cv_scores.mean() > 0.5


def test_isolation_forest_flags_more_malicious_than_benign():
    df = generate_dataset(1500)
    X, _, _ = build_feature_matrix(df)
    benign_mask = df["is_malicious"].values == 0
    model = train_isolation_forest(X[benign_mask])
    is_anomaly, _ = score_anomalies(model, X)
    malicious_rate = is_anomaly[~benign_mask].mean()
    benign_rate = is_anomaly[benign_mask].mean()
    assert malicious_rate >= benign_rate


def test_hierarchical_pipeline_end_to_end():
    train_df = generate_dataset(1200, seed=1)
    test_df = generate_dataset(400, seed=2)
    fw = HierarchicalFirewall()
    fw.fit(train_df)
    results = fw.predict(test_df)
    assert "final_prediction" in results.columns
    assert "decision_tier" in results.columns
    acc = (results["final_prediction"] == results["is_malicious"]).mean()
    assert acc > 0.6
